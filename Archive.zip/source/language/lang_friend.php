<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_friend.php 27449 2012-02-01 05:32:35Z zhangguosheng $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$lang = array(
	'friend_group_default' => '其他',
	'friend_group_1' => '通过本站认识',
	'friend_group_2' => '通过活动认识',
	'friend_group_3' => '通过朋友认识',
	'friend_group_4' => '亲人',
	'friend_group_5' => '同事',
	'friend_group_6' => '同学',
	'friend_group_7' => '不认识',
	'friend_group_more' => '自定义{num}'
);

?>