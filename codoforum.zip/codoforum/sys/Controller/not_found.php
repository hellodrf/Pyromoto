<?php

namespace Controller;

class not_found {
    

    public function __construct() {
    
        $this->view = 'not_found';
    }
}
