<?php

namespace Controller;

class home extends forum {

    public $view = false;

    public function __construct() {

        parent::__construct(array());
    }

}