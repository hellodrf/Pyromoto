The Lib directory is for classes created by CODOLOGIC that are original
to Codoforum.  It follows the PSR-0 naming convention
for classes and namespaces

The vendor namespace is "Lib".
