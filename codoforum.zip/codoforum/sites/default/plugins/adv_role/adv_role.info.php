<?php

$info['name'] = 'Advanced Role system';
$info['description'] = 'Provides more settings to configure roles/groups';
$info['version'] = '1.x';
$info['author'] = "Codologic";
$info['author_url'] = 'https://codoforum.com';
$info['license'] = 'GNU GPL V3';
$info['core'] = '1.x';
