<?php

$info['name'] = 'FreiChat';
$info['description'] = 'Provides option to integrate with FreiChat';
$info['version'] = '2.x';
$info['author'] = "Codologic";
$info['author_url'] = 'https://freichat.com';
$info['license'] = 'Codologic License';
$info['core'] = '4.x';
